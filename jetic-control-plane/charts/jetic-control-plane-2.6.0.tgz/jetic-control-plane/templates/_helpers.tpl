{{/*
Expand the name of the chart.
*/}}
{{- define "jetic-control-plane.name" -}}
{{- .Chart.Name | trunc 63 | trimSuffix "-" }}
{{- end }}

{{/*
Create a default fully qualified app name.
We truncate at 55 chars because some Kubernetes name fields are limited to this (by the DNS naming spec).
If release name contains chart name it will be used as a full name.
*/}}
{{- define "jetic-control-plane.fullname" -}}
{{- $name := .Chart.Name  }}
{{- if contains $name .Release.Name }}
{{- .Release.Name | trunc 55 | trimSuffix "-" }}
{{- else }}
{{- printf "%s-%s" .Release.Name $name | trunc 55 | trimSuffix "-" }}
{{- end }}
{{- end }}

{{/*
Create chart name and version as used by the chart label.
*/}}
{{- define "jetic-control-plane.chart" -}}
{{- printf "%s-%s" .Chart.Name .Chart.Version | replace "+" "_" | trunc 55 | trimSuffix "-" }}
{{- end }}

{{/*
Common labels
*/}}
{{- define "jetic-control-plane.labels" -}}
helm.sh/chart: {{ include "jetic-control-plane.chart" . }}
{{ include "jetic-control-plane.selectorLabels" . }}
{{- if .Chart.AppVersion }}
app.kubernetes.io/version: {{ .Chart.AppVersion | quote }}
{{- end }}
app.kubernetes.io/managed-by: {{ .Release.Service }}
app.kubernetes.io/namespace: {{ .Release.Namespace }}
{{- end }}

{{/*
Selector labels
*/}}
{{- define "jetic-control-plane.selectorLabels" -}}
app.kubernetes.io/name: {{ include "jetic-control-plane.name" . }}
app.kubernetes.io/instance: {{ .Release.Name }}
{{- end }}

{{/*
Selector labels
*/}}
{{- define "jetic-control-plane.camel-k.selectorLabels" -}}
app.kubernetes.io/instance: {{ .Release.Name }}
{{- end -}}

{{/*
Common labels
*/}}
{{- define "jetic-control-plane.camel-k.labels" -}}
helm.sh/chart: {{ include "jetic-control-plane.chart" . }}
{{ include "jetic-control-plane.camel-k.selectorLabels" . }}
{{- if .Values.operator.version }}
app.kubernetes.io/version: {{ .Values.operator.version | quote }}
{{- end }}
app.kubernetes.io/managed-by: {{ .Release.Service }}
app.kubernetes.io/namespace: {{ .Release.Namespace }}
{{- end -}}

{{/*
Create the name of the service account to use
*/}}
{{- define "jetic-control-plane.serviceAccountName" -}}
{{ include "jetic-control-plane.fullname" . }}
{{- end }}
{{/*
Create the name of the persistent volumes to use
*/}}
{{- define "jetic-control-plane.git" -}}
{{ include "jetic-control-plane.fullname" . }}-git
{{- end }}

{{/*
Generate the .dockerconfigjson file unencoded
*/}}
{{- define "dockerconfigjson.b64dec" }}
{{- print "{\"auths\":{" }}
{{- printf "\"%s\":{\"auth\":\"%s\"}" (default "https://index.docker.io/v1/" .Values.docker.registry) (printf "%s:%s" (required "docker.username is required!" .Values.docker.username) (required "docker.token is required!" .Values.docker.token) | b64enc) }}
{{- print "}}" }}
{{- end }}

{{/*
Generate the base64-encoded .dockerconfigjson
*/}}
{{- define "dockerconfigjson.b64enc" }}
{{- include "dockerconfigjson.b64dec" . | b64enc }}
{{- end }}
