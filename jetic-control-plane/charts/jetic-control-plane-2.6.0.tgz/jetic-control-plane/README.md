The Jetic Platform is an integration development tool designed to streamline the process of creating, managing, and deploying software integrations in Kubernetes. It is built on top of [Camel K](https://docs.jetic.io/docs/GettingStarted/what_is_apache_camel_k), a lightweight integration framework specifically designed for running serverless and microservice architectures natively in [Kubernetes](https://docs.jetic.io/docs/GettingStarted/what_is_kubernetes).

<img src="https://docs.jetic.io/assets/images/jetic_platform_overview-29139ea4a3e0dbcf327e40e847fd72ab.png">

## HelmChart
We have created Jetic HelmChart present at `/path/to/helmchart`. To use this helmchart for multiple cloud providers the following configuraions needs to be changed in `values.yaml`

##### AWS
- You have to change `cloudProvider` value to `aws` and have to provide AWS EFS id in `fileSystemId` field.
    ```yaml
    storage:
    enable: true
    cloudProvider: aws
    fileSystemId: "fs-123456"
    directoryPerms: ""
    gidRange: ""
    ```

##### Azure
- You only have to change `cloudProvider` value to `azure`
    ```yaml
    storage:
    enable: true
    cloudProvider: azure
    ```
##### GCP
- You have to change `cloudProvider` value to `gcp` and need to provide name of you Cloud Storage Bucket in `bucketName` field.
    ```yaml
    storage:
    enable: true
    cloudProvider: gcp
    bucketName: "mybucket"
    readOnly: false
    annotations:
        gke-gcsfuse/volumes: "true" #Required
        gke-gcsfuse/cpu-limit: 500m
        gke-gcsfuse/memory-limit: 100Mi
        gke-gcsfuse/ephemeral-storage-limit: 5Gi  
    ```

#### Kubernetes Installation
- Update you CLI with respected Cloud Provider credentials and update the kubeconfig file `~/.kube/config` for respected kubernetes cluster.
- Run below command to install the helmchart
    ```bash
    $ helm install jetic-control-plane /path/to/chart -n jetic --create-namespace
    ```
- Verify Pods, PV, PVC and StorageClass creation and bound status using below commands -
    ```bash
    $ kubectl get storageClass -n jetic
    $ kubectl get pv -n jetic
    $ kubectl get pvc -n jetic
    $ kubectl get pods -n jetic
    ```

- Run below command to uninstall the helmchart
    ```bash
    $ helm uninstall jetic-control-plane -n jetic
    ```

***

![jetic platform](https://app.jetic.io/static/media/jetic-logo.55b8bab9.svg)

For more information, please visit [documentation](https://docs.jetic.io/docs/InstallationGuide/connect_to_jetic)